# AI Telefonist

## Så här gör du:

1. Kopiera `.env.example` till `.env` och fyll i din OpenAI API-nyckel.
2. Kör `npm install` för att installera beroenden.
3. Starta med `node app.js`
4. Koppla din Twilio webhook till `/twilio-voice`
